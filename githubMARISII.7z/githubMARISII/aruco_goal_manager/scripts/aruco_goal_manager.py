#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
aruco_goal_manager.py--- for future MARIS user- you can find this code on my github or from prof saliba

Goal:
-  Python script publishes a FINAL goal (Hall -> Kitchen) on goal_in_topic.
- This manager optionally performs an Ackermann-friendly "yaw scan" to detect ArUco marker.
- If marker is found, it creates an intermediate SUBGOAL at a safe distance (0.8 m) from marker.
- It publishes subgoal to move_base, waits until robot reaches near it, then publishes the FINAL goal.

Key idea:
- We do NOT modify move_base internals.
- We do NOT modify RRT* plugin.
- We only insert an intermediate goal to reduce search and help alignment in RIS.

Assumptions:
- aruco_ros publishes PoseStamped on aruco_pose_topic in camera_frame.
- TF is available:
    map -> odom_combined -> base_link/base_footprint
    base -> camera_link
"""

import rospy
import math
from geometry_msgs.msg import PoseStamped, Twist
import tf2_ros
import tf2_geometry_msgs


def yaw_from_quat(q):
    """Compute yaw from quaternion."""
    # q is geometry_msgs/Quaternion
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quat_from_yaw(yaw):
    """Create quaternion from yaw only."""
    from geometry_msgs.msg import Quaternion
    q = Quaternion()
    q.x = 0.0
    q.y = 0.0
    q.z = math.sin(yaw * 0.5)
    q.w = math.cos(yaw * 0.5)
    return q


class ArucoGoalManager(object):
    def __init__(self):
        # ------------------------
        # Parameters
        # ------------------------
        self.map_frame = rospy.get_param("~map_frame", "map")
        self.base_frame = rospy.get_param("~base_frame", "base_link")
        self.camera_frame = rospy.get_param("~camera_frame", "camera_link")

        self.marker_id = rospy.get_param("~marker_id", 1)
        self.marker_size_m = rospy.get_param("~marker_size_m", 0.10)

        self.aruco_pose_topic = rospy.get_param("~aruco_pose_topic", "/aruco_simple/pose")
        self.goal_in_topic = rospy.get_param("~goal_in_topic", "/rrtstar_final_goal")
        self.goal_out_topic = rospy.get_param("~goal_out_topic", "/move_base_simple/goal")
        self.cmd_vel_topic = rospy.get_param("~cmd_vel_topic", "/cmd_vel")

        self.enable_scan = rospy.get_param("~enable_scan", True)
        self.scan_timeout_s = rospy.get_param("~scan_timeout_s", 4.0)
        self.scan_linear_speed = rospy.get_param("~scan_linear_speed", 0.06)
        self.scan_angular_z = rospy.get_param("~scan_angular_z", 0.35)
        self.scan_burst_s = rospy.get_param("~scan_burst_s", 0.8)

        self.safe_distance_m = rospy.get_param("~safe_distance_m", 0.8)
        self.subgoal_reached_tol_m = rospy.get_param("~subgoal_reached_tol_m", 0.25)

        self.republish_goal_times = rospy.get_param("~republish_goal_times", 3)
        self.republish_dt_s = rospy.get_param("~republish_dt_s", 0.2)
        self.subgoal_timeout_s = rospy.get_param("~subgoal_timeout_s", 30.0)

        # ------------------------
        # TF
        # ------------------------
        self.tf_buffer = tf2_ros.Buffer(cache_time=rospy.Duration(10.0))
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        # ------------------------
        # ROS pubs/subs
        # ------------------------
        self.goal_pub = rospy.Publisher(self.goal_out_topic, PoseStamped, queue_size=1)
        self.cmd_pub = rospy.Publisher(self.cmd_vel_topic, Twist, queue_size=1)

        self.final_goal = None
        self.marker_pose_cam = None    # PoseStamped in camera frame

        rospy.Subscriber(self.goal_in_topic, PoseStamped, self.goal_in_cb, queue_size=1)
        rospy.Subscriber(self.aruco_pose_topic, PoseStamped, self.aruco_cb, queue_size=1)

        rospy.loginfo("ArucoGoalManager ready.")
        rospy.loginfo("Waiting for FINAL goals on: %s", self.goal_in_topic)
        rospy.loginfo("Listening marker pose on: %s", self.aruco_pose_topic)

    # ------------------------
    # Callbacks
    # ------------------------
    def goal_in_cb(self, msg):
        """Receive final goal from  mission Python script."""
        self.final_goal = msg
        rospy.loginfo("Received FINAL goal: frame=%s x=%.3f y=%.3f",
                      msg.header.frame_id, msg.pose.position.x, msg.pose.position.y)
        self.run_once()

    def aruco_cb(self, msg):
        """Store latest marker pose (PoseStamped) coming from aruco_ros."""
        self.marker_pose_cam = msg

    # ------------------------
    # Core behaviour
    # ------------------------
    def run_once(self):
        """
        Main logic:
        1) Optional scan to improve chance of marker detection.
        2) If marker detected -> compute subgoal in map and publish it.
        3) Wait near subgoal -> publish final goal.
        4) If marker not detected -> publish final directly.
        """
        if self.final_goal is None:
            return

        # Ensure final goal is in map frame ( script already uses map)
        if self.final_goal.header.frame_id != self.map_frame:
            rospy.logwarn("Final goal frame is %s not %s. should publish in map.",
                          self.final_goal.header.frame_id, self.map_frame)

        # 1) Try scan
        marker_map = None
        if self.enable_scan:
            marker_map = self.scan_and_get_marker_map_pose(timeout_s=self.scan_timeout_s)

        # 2) Decide subgoal or direct
        if marker_map is None:
            rospy.logwarn("Marker not found. Sending FINAL goal directly.")
            self.publish_goal(self.final_goal)
            return

        # 3) Compute a safe subgoal 0.8m away from the marker (towards robot)
        subgoal = self.compute_safe_subgoal(marker_map, self.safe_distance_m)

        rospy.loginfo("Publishing SUBGOAL near marker (safe dist %.2f m).", self.safe_distance_m)
        self.publish_goal(subgoal)

        # 4) Wait until robot is close to subgoal, then publish final goal
        if self.wait_until_near_pose(subgoal, self.subgoal_reached_tol_m, timeout_s=self.subgoal_timeout_s):
            rospy.loginfo("Reached near SUBGOAL. Publishing FINAL goal now.")
        else:
            rospy.logwarn("Did not reach subgoal within timeout. Publishing FINAL goal anyway.")

        self.publish_goal(self.final_goal)

    def scan_and_get_marker_map_pose(self, timeout_s):
        """
        Ackermann-friendly scan:
        - Cannot rotate in place.
        - We do short forward arcs left and right.
        - During scan we keep checking if marker pose exists and can be TF transformed to map frame.
        """
        t0 = rospy.Time.now().to_sec()
        direction = 1.0

        rate = rospy.Rate(20)

        while (rospy.Time.now().to_sec() - t0) < timeout_s and not rospy.is_shutdown():
            marker_map = self.try_transform_marker_to_map()
            if marker_map is not None:
                rospy.loginfo("Marker found and transformed into map frame.")
                self.stop_robot()
                return marker_map

            # Do one short arc
            self.arc_motion(direction, self.scan_linear_speed, self.scan_angular_z, self.scan_burst_s)
            direction *= -1.0
            rate.sleep()

        self.stop_robot()
        return None

    def try_transform_marker_to_map(self):
        """
        Convert marker pose (camera frame) -> map frame.
        Returns PoseStamped in map frame or None.
        """
        if self.marker_pose_cam is None:
            return None

        try:
            # Transform marker pose into map frame
            T = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.marker_pose_cam.header.frame_id,
                rospy.Time(0),
                rospy.Duration(0.1)
            )
            marker_map = tf2_geometry_msgs.do_transform_pose(self.marker_pose_cam, T)
            marker_map.header.frame_id = self.map_frame
            return marker_map

        except Exception:
            return None

    def compute_safe_subgoal(self, marker_map, safe_dist):
        """
        Subgoal strategy (simple, robust):
        - Find robot pose in map.
        - Compute vector from marker -> robot.
        - Place subgoal at safe_dist from marker along that vector.

        This ensures robot approaches marker but stops short by safe_dist.
        """
        robot_x, robot_y, robot_yaw = self.get_robot_pose_map()

        mx = marker_map.pose.position.x
        my = marker_map.pose.position.y

        vx = robot_x - mx
        vy = robot_y - my
        norm = math.sqrt(vx*vx + vy*vy)

        # If robot is extremely close, pick a default direction
        if norm < 1e-3:
            vx, vy = 1.0, 0.0
            norm = 1.0

        vx /= norm
        vy /= norm

        # subgoal point at safe_dist away from marker towards robot
        gx = mx + vx * safe_dist
        gy = my + vy * safe_dist

        # Orientation: face marker
        yaw_to_marker = math.atan2(my - gy, mx - gx)

        g = PoseStamped()
        g.header.frame_id = self.map_frame
        g.header.stamp = rospy.Time.now()
        g.pose.position.x = gx
        g.pose.position.y = gy
        g.pose.position.z = 0.0
        g.pose.orientation = quat_from_yaw(yaw_to_marker)
        return g

    def get_robot_pose_map(self):
        """Get robot pose (x, y, yaw) in map frame using TF."""
        T = self.tf_buffer.lookup_transform(
            self.map_frame,
            self.base_frame,
            rospy.Time(0),
            rospy.Duration(0.2)
        )
        x = T.transform.translation.x
        y = T.transform.translation.y
        yaw = yaw_from_quat(T.transform.rotation)
        return x, y, yaw

    def wait_until_near_pose(self, target_pose, tol_m, timeout_s=30.0):
        """Wait until robot is within tol_m of target_pose in map frame."""
        t0 = rospy.Time.now().to_sec()
        rate = rospy.Rate(10)

        while (rospy.Time.now().to_sec() - t0) < timeout_s and not rospy.is_shutdown():
            try:
                rx, ry, _ = self.get_robot_pose_map()
                dx = rx - target_pose.pose.position.x
                dy = ry - target_pose.pose.position.y
                d = math.sqrt(dx*dx + dy*dy)
                if d <= tol_m:
                    return True
            except Exception:
                pass
            rate.sleep()

        return False

    def publish_goal(self, pose_stamped):
        """Publish same goal multiple times to ensure it is received."""
        pose_stamped.header.stamp = rospy.Time.now()
        for _ in range(self.republish_goal_times):
            self.goal_pub.publish(pose_stamped)
            rospy.sleep(self.republish_dt_s)

    def arc_motion(self, direction, v, omega, duration_s):
        """
        Send cmd_vel for a short time.
        direction = +1 or -1 flips angular sign.
        cmd_vel_to_ackermann script will convert (v, omega) -> steering angle.
        """
        msg = Twist()
        msg.linear.x = v
        msg.angular.z = direction * omega

        t0 = rospy.Time.now().to_sec()
        rate = rospy.Rate(20)
        while (rospy.Time.now().to_sec() - t0) < duration_s and not rospy.is_shutdown():
            self.cmd_pub.publish(msg)
            rate.sleep()

        self.stop_robot()

    def stop_robot(self):
        msg = Twist()
        msg.linear.x = 0.0
        msg.angular.z = 0.0
        for _ in range(5):
            self.cmd_pub.publish(msg)
            rospy.sleep(0.02)


if __name__ == "__main__":
    rospy.init_node("aruco_goal_manager", anonymous=False)
    node = ArucoGoalManager()
    rospy.spin()

