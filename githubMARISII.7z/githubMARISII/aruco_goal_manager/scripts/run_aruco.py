#!/usr/bin/env python3
import os
import sys
import subprocess

import rospy

"""
Wrapper node that launches the aruco_ros single marker detector for MARIS.
It assumes:
  - Camera image topic: /camera/rgb/image_raw
  - Marker ID: 23 (change if needed)
  - Marker size: 0.10 (meters, adjust to marker)
It will publish:
  - /aruco_single/pose   (geometry_msgs/PoseStamped)
  - /aruco_single/result (aruco_msgs/MarkerArray)
"""

def main():
    rospy.init_node("run_aruco_wrapper")

    # Parameters (you can override via rosparam if needed)
    marker_id = rospy.get_param("~marker_id", 23)
    marker_size = rospy.get_param("~marker_size", 0.10)
    image_topic = rospy.get_param("~image_topic", "/camera/rgb/image_raw")

    rospy.loginfo("Starting aruco_ros single marker node...")
    rospy.loginfo("  marker_id: %d", marker_id)
    rospy.loginfo("  marker_size: %.3f m", marker_size)
    rospy.loginfo("  image_topic: %s", image_topic)

    # Build the rosrun command
    cmd = [
        "rosrun",
        "aruco_ros",
        "single",
        str(marker_id),
        str(marker_size),
        "/camera",  # camera name
        image_topic
    ]

    rospy.loginfo("Executing: %s", " ".join(cmd))

    # Launch aruco_ros as a subprocess
    try:
        proc = subprocess.Popen(cmd)
    except Exception as e:
        rospy.logerr("Failed to start aruco_ros single: %s", str(e))
        return

    rospy.loginfo("aruco_ros single started with PID %d", proc.pid)

    # Keep this wrapper node alive while the subprocess runs
    try:
        while not rospy.is_shutdown():
            ret = proc.poll()
            if ret is not None:
                rospy.logwarn("aruco_ros single exited with code %d", ret)
                break
            rospy.sleep(0.5)
    except rospy.ROSInterruptException:
        pass
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except Exception:
                pass

if __name__ == "__main__":
    main()

