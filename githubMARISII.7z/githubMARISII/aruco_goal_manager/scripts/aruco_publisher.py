#!/usr/bin/env python
import rospy
from geometry_msgs.msg import PoseStamped

rospy.init_node("fake_aruco_publisher")

pub = rospy.Publisher("/aruco_single/pose", PoseStamped, queue_size=1)

rate = rospy.Rate(2)

while not rospy.is_shutdown():
    msg = PoseStamped()
    msg.header.stamp = rospy.Time.now()
    msg.header.frame_id = "map"

    # marker in front of robot
    msg.pose.position.x = 2.0
    msg.pose.position.y = 0.0
    msg.pose.position.z = 0.0
    msg.pose.orientation.w = 1.0

    pub.publish(msg)
    rate.sleep()
