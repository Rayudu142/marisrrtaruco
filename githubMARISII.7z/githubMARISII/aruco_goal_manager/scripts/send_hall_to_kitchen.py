#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import PoseStamped

if __name__ == "__main__":
    rospy.init_node("send_hall_to_kitchen", anonymous=False)

    pub = rospy.Publisher("/rrtstar_final_goal", PoseStamped, queue_size=1, latch=True)
    rospy.sleep(1.0)

    # Kitchen goal script
    g = PoseStamped()
    g.header.frame_id = "map"
    g.header.stamp = rospy.Time.now()
    g.pose.position.x = 0.994
    g.pose.position.y = 0.464
    g.pose.position.z = 0.0
    g.pose.orientation.x = 0.000
    g.pose.orientation.y = -0.005
    g.pose.orientation.z = -0.009
    g.pose.orientation.w = 1.000

    rospy.loginfo("Publishing FINAL goal (kitchen) to /rrtstar_final_goal")
    for _ in range(5):
        g.header.stamp = rospy.Time.now()
        pub.publish(g)
        rospy.sleep(0.2)

    rospy.loginfo("Done. Manager will handle scan, subgoal, then final goal.")

