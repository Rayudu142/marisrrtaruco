#ifndef RRT_STAR_PLANNER_H
#define RRT_STAR_PLANNER_H

#include <ros/ros.h>
#include <nav_core/base_global_planner.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>

#include <tf2/utils.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <angles/angles.h>

#include <random>
#include <vector>
#include <string>

namespace rrt_star_planner
{

struct Node
{
  double x;
  double y;
  double yaw;

  Node() : x(0.0), y(0.0), yaw(0.0) {}
  Node(double _x, double _y, double _yaw) : x(_x), y(_y), yaw(_yaw) {}
};

class RRTStarPlanner : public nav_core::BaseGlobalPlanner
{
public:
  RRTStarPlanner();
  RRTStarPlanner(std::string name, costmap_2d::Costmap2DROS* costmap_ros);

  void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros) override;

  bool makePlan(const geometry_msgs::PoseStamped& start,
                const geometry_msgs::PoseStamped& goal,
                std::vector<geometry_msgs::PoseStamped>& plan) override;

private:
  bool initialized_;
  costmap_2d::Costmap2DROS* costmap_ros_;
  costmap_2d::Costmap2D* costmap_;
  ros::Publisher plan_pub_;

  // Params
  int max_iterations_;
  double max_planning_time_;
  double step_size_;
  double goal_bias_;
  double goal_xy_tolerance_;
  double goal_yaw_tolerance_;
  double search_radius_;
  double min_turning_radius_;
  double collision_check_resolution_;
  bool minimal_mode_;
  bool reuse_tree_;
  double reuse_start_tol_;
  double reuse_goal_tol_;

  // New critical params for SLAM maps
  bool allow_unknown_;
  int lethal_cost_;

  // State
  std::vector<Node> tree_;
  std::mt19937 rng_;
  std::uniform_real_distribution<double> uni_;

  bool has_last_problem_;
  Node last_start_;
  Node last_goal_;

  // Helpers
  Node poseToNode(const geometry_msgs::PoseStamped& pose) const;
  double distanceXY(const Node& a, const Node& b) const;
  double normalizeYaw(double yaw) const;

  bool isStateValid(double x, double y) const;
  bool isMotionValid(const Node& a, const Node& b) const;

  Node sampleRandomState(const Node& goal);
  int nearestNode(const Node& q) const;
  std::vector<int> nearNodes(const Node& q) const;
  int extendTree(int near_idx, const Node& q_rand);
  void rewire(int new_idx);

  bool goalReached(const Node& q, const Node& goal) const;
  void extractPath(const Node& goal, std::vector<geometry_msgs::PoseStamped>& plan) const;
};

} // namespace rrt_star_planner

#endif

