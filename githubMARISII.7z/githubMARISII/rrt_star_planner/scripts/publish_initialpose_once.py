#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseWithCovarianceStamped
import tf.transformations as tft

def main():
    rospy.init_node("publish_initialpose_once")

    delay = float(rospy.get_param("~delay", 0.1))
    frame = rospy.get_param("~frame_id", "map")
    x = float(rospy.get_param("~x", 0.0))
    y = float(rospy.get_param("~y", 0.0))
    yaw = float(rospy.get_param("~yaw", 0.0))

    pub = rospy.Publisher("/initialpose", PoseWithCovarianceStamped, queue_size=1, latch=True)

    rospy.sleep(delay)

    msg = PoseWithCovarianceStamped()
    msg.header.stamp = rospy.Time.now()
    msg.header.frame_id = frame
    msg.pose.pose.position.x = x
    msg.pose.pose.position.y = y
    msg.pose.pose.position.z = 0.0

    q = tft.quaternion_from_euler(0.0, 0.0, yaw)
    msg.pose.pose.orientation.x = q[0]
    msg.pose.pose.orientation.y = q[1]
    msg.pose.pose.orientation.z = q[2]
    msg.pose.pose.orientation.w = q[3]

    msg.pose.covariance = [0.0] * 36
    msg.pose.covariance[0] = 0.25
    msg.pose.covariance[7] = 0.25
    msg.pose.covariance[35] = 0.0685

    pub.publish(msg)
    rospy.loginfo("Published /initialpose once: x=%.3f y=%.3f yaw=%.3f frame=%s", x, y, yaw, frame)

    rospy.sleep(0.3)

if __name__ == "__main__":
    main()

