#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
dsafe_logger.py

Purpose:
- Send 3 navigation goals (kitchen, bedroom, hall) using move_base.
- For each goal, measure and print:
    * Planning latency = time from goal_sent to first motion (/cmd_vel).
- For the THIRD goal (hall), also:
    * Automatically "brake" by cancelling the goal after the robot is cruising.
    * Measure v_start (speed just before brake) from /odom.
    * Measure stopping time (t_stop - t_brake).
    * Estimate deceleration a_est = v_start / (t_stop - t_brake).

These values (v_start and a_est) are what you need for the D_safe formula
(M_sensor = v * t_latency, M_brake = v^2 / (2a)).

Usage:
  Terminal 1: roslaunch turn_on_wheeltec_robot navigation.launch
  Terminal 2: rosrun turn_on_wheeltec_robot chapter9_dsafe_logger.py
"""

import rospy
import math

from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from move_base_msgs.msg import MoveBaseActionResult
from actionlib_msgs.msg import GoalID


class DSafeLogger(object):
    def __init__(self):
        # --------------------------------------------------------------
        # GOALS: positions in map frame 
        # --------------------------------------------------------------
        # Kitchen
        self.goals = [
            {
                "name": "kitchen",
                "x": 0.994,
                "y": 0.464,
                "z": 0.000,
                "qx": 0.000,
                "qy": -0.005,
                "qz": -0.009,
                "qw": 1.000,
            },
            # Bedroom
            {
                "name": "bedroom",
                "x": 2.428,
                "y": -0.863,
                "z": 0.000,
                "qx": -0.000,
                "qy": 0.001,
                "qz": -0.740,
                "qw": 0.673,
            },
            # Hall (using your "delivery" coordinates)
            {
                "name": "hall",
                "x": -0.818,
                "y": -0.768,
                "z": 0.000,
                "qx": -0.006,
                "qy": 0.001,
                "qz": 1.000,
                "qw": 0.021,
            },
        ]

        # --------------------------------------------------------------
        # PARAMETERS / CONSTANTS
        # --------------------------------------------------------------
        # Threshold to consider that robot started moving (from /cmd_vel)
        self.MOVE_CMD_THRESH = 1e-3

        # For braking measurement
        self.CRUISE_MIN_SPEED = 0.25     # m/s (robot at "cruise" before brake)
        self.MIN_CRUISE_TIME  = 2.0      # s after movement start before we brake
        self.STOP_SPEED_MAX   = 0.02     # m/s, consider robot stopped

        # --------------------------------------------------------------
        # STATE VARIABLES
        # --------------------------------------------------------------
        self.current_goal_index = -1      # which goal we are on
        self.run_in_progress    = False   # true when a goal is active
        self.nav_active         = False   # true after first motion detected
        self.run_finished       = False   # this goal finished

        self.t_goal_sent   = None         # time when we published goal
        self.t_move_start  = None         # time when /cmd_vel first shows motion

        # Braking-related state (for hall run only)
        self.brake_started   = False      # we already triggered brake
        self.decel_done      = False      # we already measured a_est
        self.t_brake_start   = None       # time when we cancelled goal
        self.v_start_brake   = None       # speed just before brake
        self.t_stop          = None       # time when robot stopped after brake

        # For average navigation speed (not strictly needed but useful)
        self.sum_nav_speed   = 0.0
        self.count_nav_speed = 0

        # --------------------------------------------------------------
        # ROS I/O
        # --------------------------------------------------------------
        # Publisher for simple goals
        self.goal_pub = rospy.Publisher(
            "/move_base_simple/goal", PoseStamped, queue_size=1
        )

        # Publisher to cancel current move_base goal (used for braking)
        self.cancel_pub = rospy.Publisher(
            "/move_base/cancel", GoalID, queue_size=1
        )

        # Subscriber to /cmd_vel to detect first movement (planner latency)
        self.cmd_vel_sub = rospy.Subscriber(
            "/cmd_vel", Twist, self.cmd_vel_cb, queue_size=10
        )

        # Subscriber to /odom to get speed and braking profile
        self.odom_sub = rospy.Subscriber(
            "/odom", Odometry, self.odom_cb, queue_size=20
        )

        # Subscriber to /move_base/result to detect when goals succeed
        self.result_sub = rospy.Subscriber(
            "/move_base/result", MoveBaseActionResult, self.result_cb, queue_size=10
        )

        rospy.sleep(1.0)  # small delay for topics to be ready
        rospy.loginfo("DSafeLogger started, sending first goal shortly.")
        self.advance_to_next_goal()

    # --------------------------------------------------------------
    # GOAL MANAGEMENT
    # --------------------------------------------------------------
    def advance_to_next_goal(self):
        """Move to next goal or finish after all three goals."""
        self.current_goal_index += 1

        if self.current_goal_index >= len(self.goals):
            rospy.loginfo("All goals done. D_safe measurements complete.")
            rospy.signal_shutdown("Finished all goals.")
            return

        goal = self.goals[self.current_goal_index]

        # Reset state for this run
        self.run_in_progress = True
        self.nav_active      = False
        self.run_finished    = False

        self.t_goal_sent  = rospy.Time.now().to_sec()
        self.t_move_start = None

        # Reset braking flags
        self.brake_started   = False
        self.decel_done      = False
        self.t_brake_start   = None
        self.v_start_brake   = None
        self.t_stop          = None

        self.sum_nav_speed   = 0.0
        self.count_nav_speed = 0

        rospy.loginfo("------------------------------------------------")
        rospy.loginfo(
            "Starting run to goal %d: '%s'",
            self.current_goal_index + 1,
            goal["name"],
        )

        # Build PoseStamped in map frame
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.header.stamp = rospy.Time.now()
        pose.pose.position.x = goal["x"]
        pose.pose.position.y = goal["y"]
        pose.pose.position.z = goal["z"]
        pose.pose.orientation.x = goal["qx"]
        pose.pose.orientation.y = goal["qy"]
        pose.pose.orientation.z = goal["qz"]
        pose.pose.orientation.w = goal["qw"]

        # Publish the goal a few times to be sure it is received
        for _ in range(5):
            self.goal_pub.publish(pose)
            rospy.sleep(0.5)

        rospy.loginfo(
            "Goal '%s' sent at t = %.2f s",
            goal["name"],
            self.t_goal_sent,
        )

    # --------------------------------------------------------------
    # /cmd_vel CALLBACK  (detect first movement)
    # --------------------------------------------------------------
    def cmd_vel_cb(self, msg):
        """
        Detect when the robot starts moving (first non-zero velocity command).
        That moment gives us t_move_start, so we can compute planner latency:
            latency = t_move_start - t_goal_sent
        """
        if not self.run_in_progress or self.run_finished:
            return

        # Combine linear + angular into a single measure of "activity"
        v_mag = abs(msg.linear.x) + abs(msg.linear.y) + abs(msg.angular.z)

        # If we have not yet seen motion and now command is non-zero, this is movement start.
        if (not self.nav_active) and (self.t_goal_sent is not None) and (v_mag > self.MOVE_CMD_THRESH):
            self.t_move_start = rospy.Time.now().to_sec()
            self.nav_active = True

            latency = self.t_move_start - self.t_goal_sent
            goal = self.goals[self.current_goal_index]
            rospy.loginfo(
                "Goal '%s': movement started at t = %.2f s, planner latency = %.3f s",
                goal["name"],
                self.t_move_start,
                latency,
            )

    # --------------------------------------------------------------
    # /odom CALLBACK  (speed + braking measurement)
    # --------------------------------------------------------------
    def odom_cb(self, msg):
        """
        Read robot's forward speed from /odom.twist.twist.linear.x.
        - While nav is active, accumulate speed samples (for info).
        - On the third goal (hall), after some time at cruise speed,
          cancel the goal (brake) and then measure stopping time to estimate a_est.
        """
        if not self.run_in_progress or self.t_move_start is None:
            return

        # Forward velocity (assuming x is forward in odom frame).
        vx = msg.twist.twist.linear.x
        now = rospy.Time.now().to_sec()

        # Accumulate navigation speed for information
        if self.nav_active and (not self.run_finished):
            self.sum_nav_speed   += abs(vx)
            self.count_nav_speed += 1

        # We only do braking measurement on the THIRD goal (index 2, name "hall")
        is_hall_run = (self.current_goal_index == 2)

        if not is_hall_run:
            # For kitchen/bedroom we do not interfere; let move_base stop normally.
            return

        # If navigation is active, we have t_move_start and robot is executing path.
        if self.nav_active and (not self.brake_started):
            # Check if robot has reached some cruise speed and some time passed
            time_since_move = now - self.t_move_start
            if (time_since_move > self.MIN_CRUISE_TIME) and (abs(vx) > self.CRUISE_MIN_SPEED):
                # This is our chosen "start of braking"
                self.brake_started = True
                self.t_brake_start = now
                self.v_start_brake = abs(vx)

                rospy.loginfo(
                    "HALL run: starting braking at t = %.2f s, v_start = %.3f m/s",
                    self.t_brake_start,
                    self.v_start_brake,
                )

                # Cancel the current move_base goal (this is our "brake command")
                cancel_msg = GoalID()  # empty GoalID cancels current goal
                self.cancel_pub.publish(cancel_msg)
                rospy.loginfo("HALL run: move_base goal cancelled (brake command sent).")
                return

        # After brake started, monitor until robot stops
        if self.brake_started and (not self.decel_done):
            # When the forward speed is very small, consider the robot stopped
            if abs(vx) < self.STOP_SPEED_MAX and now > self.t_brake_start:
                self.t_stop = now
                delta_t = self.t_stop - self.t_brake_start

                if delta_t > 0.0:
                    a_est = self.v_start_brake / delta_t
                else:
                    a_est = 0.0

                rospy.loginfo(
                    "HALL run: robot stopped at t = %.2f s, stopping time = %.3f s",
                    self.t_stop,
                    delta_t,
                )
                rospy.loginfo(
                    "HALL run: estimated deceleration a_est = %.3f m/s^2",
                    a_est,
                )

                # Also report average navigation speed during the hall run
                avg_speed = 0.0
                if self.count_nav_speed > 0:
                    avg_speed = self.sum_nav_speed / float(self.count_nav_speed)

                rospy.loginfo(
                    "HALL run: average navigation speed before braking ≈ %.3f m/s",
                    avg_speed,
                )

                self.decel_done = True
                self.run_finished = True
                self.nav_active = False

                # After hall braking measurement, we are done with all goals
                rospy.loginfo("HALL run braking measurement complete. Moving to next (if any).")
                self.advance_to_next_goal()

    # --------------------------------------------------------------
    # /move_base/result CALLBACK  (success for first two goals)
    # --------------------------------------------------------------
    def result_cb(self, msg):
        """
        Detect goal success from /move_base/result.
        We use this ONLY for the first two goals (kitchen, bedroom).
        The third goal (hall) is finished by our braking measurement instead.
        """
        if not self.run_in_progress or self.run_finished:
            return

        goal = self.goals[self.current_goal_index]
        is_hall_run = (self.current_goal_index == 2)

        # If it's the hall run, we ignore normal success; braking logic handles it.
        if is_hall_run:
            return

        # MoveBase status 3 == SUCCEEDED
        if msg.status.status == 3 and self.nav_active:
            t_goal_reached = rospy.Time.now().to_sec()
            travel_time = t_goal_reached - self.t_move_start if self.t_move_start is not None else 0.0

            # Average navigation speed for info
            avg_speed = 0.0
            if self.count_nav_speed > 0:
                avg_speed = self.sum_nav_speed / float(self.count_nav_speed)

            rospy.loginfo(
                "Goal '%s' reached at t = %.2f s, travel_time = %.3f s",
                goal["name"],
                t_goal_reached,
                travel_time,
            )

            if self.t_move_start is not None:
                latency = self.t_move_start - self.t_goal_sent
            else:
                latency = 0.0

            rospy.loginfo(
                "Goal '%s': planner latency = %.3f s, average nav speed ≈ %.3f m/s",
                goal["name"],
                latency,
                avg_speed,
            )

            self.run_finished = True
            self.run_in_progress = False
            self.nav_active = False

            # Proceed to next goal (bedroom then hall)
            self.advance_to_next_goal()


def main():
    rospy.init_node("dsafe_logger", anonymous=False)
    node = DSafeLogger()
    rospy.loginfo("dsafe_logger node running.")
    rospy.spin()


if __name__ == "__main__":
    main()
