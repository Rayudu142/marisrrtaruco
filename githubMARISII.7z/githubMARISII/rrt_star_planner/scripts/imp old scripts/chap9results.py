#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

- Sends 3 goals in sequence (map frame):
    1) Kitchen
    2) Bedroom
    3) Delivery point
- For EACH goal, logs:
    * Total path length (m)
    * Travel time (s)
    * Number of turns (count)
    * Peak CPU during planning (%)
    * Average CPU during navigation (%)
    * Planning latency (goal_sent -> first movement) (s)
- If more than 30 s pass after goal_sent (no success), the run is marked "timeout"
  and the next goal is started.
- Results are saved to chapter9_runs_multi.csv
"""

import rospy
import math
import csv
import os
import psutil
import tf

from geometry_msgs.msg import PoseStamped, Twist
from move_base_msgs.msg import MoveBaseActionResult


def angle_wrap(angle):
    """Wrap angle to [-pi, pi]."""
    return math.atan2(math.sin(angle), math.cos(angle))


def median_of_list(values):
    """Median of a non-empty list."""
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    mid = n // 2
    if n % 2 == 1:
        return sorted_vals[mid]
    else:
        return 0.5 * (sorted_vals[mid - 1] + sorted_vals[mid])


class MultiGoalLogger(object):
    def __init__(self):
        # ------------------------------------------------------------------
        # GOALS: positions from tf_echo map base_link (map frame)
        # ------------------------------------------------------------------
        # Kitchen point
        #  Translation: [0.994, 0.464, 0.000]
        #  Rotation: in Quaternion [0.000, -0.005, -0.009, 1.000]
        # Bedroom point
        #  Translation: [2.428, -0.863, 0.000]
        #  Rotation: in Quaternion [-0.000, 0.001, -0.740, 0.673]
        # Delivery point
        #  Translation: [-0.818, -0.768, -0.003]
        #  Rotation: in Quaternion [-0.006, 0.001, 1.000, 0.021]
        self.goals = [
            {
                "name": "kitchen",
                "x": 0.994,
                "y": 0.464,
                "z": 0.000,
                "qx": 0.000,
                "qy": -0.005,
                "qz": -0.009,
                "qw": 1.000,
            },
            {
                "name": "bedroom",
                "x": 2.428,
                "y": -0.863,
                "z": 0.000,
                "qx": -0.000,
                "qy": 0.001,
                "qz": -0.740,
                "qw": 0.673,
            },
            {
                "name": "delivery",
                "x": -0.818,
                "y": -0.768,
                "z": 0.000,   # z is ignored for ground robot
                "qx": -0.006,
                "qy": 0.001,
                "qz": 1.000,
                "qw": 0.021,
            },
        ]

        # ------------------------------------------------------------------
        # PARAMETERS
        # ------------------------------------------------------------------
        self.pose_rate_hz = rospy.get_param("~pose_rate_hz", 10.0)
        self.cpu_rate_hz = rospy.get_param("~cpu_rate_hz", 1.0)
        self.max_run_time = rospy.get_param("~max_run_time", 90.0)  # seconds

        self.turn_yaw_thresh_deg = rospy.get_param("~turn_yaw_thresh_deg", 15.0)
        self.turn_dist_thresh = rospy.get_param("~turn_dist_thresh", 0.30)      # m
        self.rearm_forward_dist = rospy.get_param("~rearm_forward_dist", 0.20)  # m

        self.csv_path = rospy.get_param("~csv_path", "chapter9_runs_multi.csv")
        self.shutdown_after_all = rospy.get_param("~shutdown_after_all", True)

        # Thresholds in radians
        self.turn_yaw_thresh = math.radians(self.turn_yaw_thresh_deg)

        # ------------------------------------------------------------------
        # STATE VARIABLES
        # ------------------------------------------------------------------
        self.tf_listener = tf.TransformListener()

        self.last_pose = None           # (x, y, yaw_filtered)
        self.last_yaw_unwrapped = None
        self.yaw_buffer = []

        self.run_id = 0
        self.current_goal_index = -1

        self.run_in_progress = False
        self.nav_active = False
        self.run_finished = False
        self.run_status = "none"        # "success" or "timeout"

        self.t_goal_sent = None
        self.t_move_start = None
        self.t_goal_reached = None
        self.run_deadline = None        # t_goal_sent + max_run_time

        self.distance_travelled = 0.0
        self.turn_count = 0

        # Turn detection
        self.in_turn = False
        self.yaw_accum = 0.0
        self.turn_forward_dist = 0.0
        self.forward_since_turn = self.rearm_forward_dist

        # CPU logging
        self.cpu_planning_samples = []
        self.cpu_nav_samples = []

        # ------------------------------------------------------------------
        # ROS I/O
        # ------------------------------------------------------------------
        self.goal_pub = rospy.Publisher(
            "/move_base_simple/goal", PoseStamped, queue_size=1
        )
        self.cmd_vel_sub = rospy.Subscriber(
            "/cmd_vel", Twist, self.cmd_vel_cb, queue_size=10
        )
        self.result_sub = rospy.Subscriber(
            "/move_base/result", MoveBaseActionResult, self.result_cb, queue_size=10
        )

        # CSV setup
        file_exists = os.path.isfile(self.csv_path)
        self.csv_file = open(self.csv_path, "a")
        self.csv_writer = csv.writer(self.csv_file)
        if not file_exists:
            self.csv_writer.writerow(
                [
                    "run_id",
                    "goal_name",
                    "goal_x",
                    "goal_y",
                    "distance_m",
                    "travel_time_s",
                    "planning_latency_s",
                    "turn_count",
                    "cpu_plan_peak",
                    "cpu_nav_mean",
                    "status",
                ]
            )
        rospy.loginfo("Logging metrics to %s", self.csv_path)

        # Prime psutil
        psutil.cpu_percent(interval=None)

        # Timers
        self.pose_timer = rospy.Timer(
            rospy.Duration(1.0 / self.pose_rate_hz), self.pose_loop
        )
        self.cpu_timer = rospy.Timer(
            rospy.Duration(1.0 / self.cpu_rate_hz), self.cpu_loop
        )

        rospy.sleep(1.0)  # small delay for TF etc.
        self.advance_to_next_goal()  # start with Kitchen

    # ------------------------------------------------------------------
    # GOAL MANAGEMENT
    # ------------------------------------------------------------------
    def advance_to_next_goal(self):
        """Move to next goal or finish if all done."""
        self.current_goal_index += 1

        if self.current_goal_index >= len(self.goals):
            rospy.loginfo("All goals completed.")
            if self.shutdown_after_all:
                rospy.signal_shutdown("All runs finished")
            return

        goal = self.goals[self.current_goal_index]

        self.run_id += 1
        self.run_in_progress = True
        self.nav_active = False
        self.run_finished = False
        self.run_status = "incomplete"

        now = rospy.Time.now().to_sec()
        self.t_goal_sent = now
        self.t_move_start = None
        self.t_goal_reached = None
        self.run_deadline = self.t_goal_sent + self.max_run_time

        self.distance_travelled = 0.0
        self.turn_count = 0

        self.in_turn = False
        self.yaw_accum = 0.0
        self.turn_forward_dist = 0.0
        self.forward_since_turn = self.rearm_forward_dist

        self.cpu_planning_samples = []
        self.cpu_nav_samples = []

        rospy.loginfo("----- Run %d: goal '%s' -----", self.run_id, goal["name"])

        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.header.stamp = rospy.Time.now()
        pose.pose.position.x = goal["x"]
        pose.pose.position.y = goal["y"]
        pose.pose.position.z = goal["z"]
        pose.pose.orientation.x = goal["qx"]
        pose.pose.orientation.y = goal["qy"]
        pose.pose.orientation.z = goal["qz"]
        pose.pose.orientation.w = goal["qw"]

        rospy.loginfo(
            "Sending goal '%s': x=%.3f, y=%.3f",
            goal["name"],
            goal["x"],
            goal["y"],
        )

        # Republish goal a few times for safety
        for _ in range(5):
            self.goal_pub.publish(pose)
            rospy.sleep(0.5)

        rospy.loginfo("Goal for '%s' sent at t=%.2f", goal["name"], self.t_goal_sent)

    # ------------------------------------------------------------------
    # CALLBACKS
    # ------------------------------------------------------------------
    def cmd_vel_cb(self, msg):
        """Detect first movement from /cmd_vel."""
        if not self.run_in_progress or self.run_finished:
            return

        v = abs(msg.linear.x) + abs(msg.linear.y) + abs(msg.angular.z)
        if v > 1e-3 and (not self.nav_active) and (self.t_goal_sent is not None):
            self.t_move_start = rospy.Time.now().to_sec()
            self.nav_active = True
            rospy.loginfo(
                "Run %d: movement started at t=%.2f",
                self.run_id,
                self.t_move_start,
            )

    def result_cb(self, msg):
        """Detect goal success from /move_base/result."""
        if not self.run_in_progress or self.run_finished:
            return

        # GoalStatus.SUCCEEDED == 3
        if msg.status.status == 3 and self.nav_active:
            self.t_goal_reached = rospy.Time.now().to_sec()
            self.run_finished = True
            self.run_in_progress = False
            self.nav_active = False
            self.run_status = "success"
            rospy.loginfo(
                "Run %d: goal succeeded at t=%.2f",
                self.run_id,
                self.t_goal_reached,
            )
            self.finish_run_and_save()
            self.advance_to_next_goal()

    # ------------------------------------------------------------------
    # POSE LOOP
    # ------------------------------------------------------------------
    def pose_loop(self, event):
        """Read TF, update distance/turns, and handle timeout."""
        try:
            now_tf = rospy.Time(0)
            self.tf_listener.waitForTransform(
                "map", "base_link", now_tf, rospy.Duration(0.05)
            )
            (trans, rot) = self.tf_listener.lookupTransform(
                "map", "base_link", now_tf
            )
            x = trans[0]
            y = trans[1]

            qx, qy, qz, qw = rot
            siny_cosp = 2.0 * (qw * qz + qx * qy)
            cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
            yaw_raw = math.atan2(siny_cosp, cosy_cosp)
        except (tf.Exception, tf.LookupException, tf.ConnectivityException):
            return

        # Yaw unwrapping
        if self.last_yaw_unwrapped is None:
            self.last_yaw_unwrapped = yaw_raw
        else:
            prev = self.last_yaw_unwrapped
            prev_mod = angle_wrap(prev)
            diff = yaw_raw - prev_mod
            if diff > math.pi:
                diff -= 2.0 * math.pi
            elif diff < -math.pi:
                diff += 2.0 * math.pi
            self.last_yaw_unwrapped = prev + diff

        yaw_unwrapped = self.last_yaw_unwrapped

        # 3-sample median filter on yaw
        self.yaw_buffer.append(yaw_unwrapped)
        if len(self.yaw_buffer) > 3:
            self.yaw_buffer.pop(0)

        if len(self.yaw_buffer) < 3:
            yaw_filtered = yaw_unwrapped
        else:
            yaw_filtered = median_of_list(self.yaw_buffer)

        # Need previous pose to compute step
        if self.last_pose is None:
            self.last_pose = (x, y, yaw_filtered)
            return

        last_x, last_y, last_yaw = self.last_pose
        dx = x - last_x
        dy = y - last_y
        step_dist = math.sqrt(dx * dx + dy * dy)
        dyaw = yaw_filtered - last_yaw

        self.last_pose = (x, y, yaw_filtered)

        # Accumulate distance and detect turns during navigation
        if self.nav_active and (not self.run_finished) and (self.t_move_start is not None):
            self.distance_travelled += step_dist
            self.update_turn_detection(step_dist, dyaw)

        # Timeout: 30 s after goal_sent
        if (
            self.run_in_progress
            and (not self.run_finished)
            and (self.t_goal_sent is not None)
        ):
            now_sec = rospy.Time.now().to_sec()
            if now_sec > self.run_deadline:
                rospy.logwarn(
                    "Run %d timed out (%.1f s > %.1f s).",
                    self.run_id,
                    now_sec - self.t_goal_sent,
                    self.max_run_time,
                )
                # If robot never moved, treat full time as planning latency
                if self.t_move_start is None:
                    self.t_move_start = self.t_goal_sent
                self.t_goal_reached = now_sec
                self.run_finished = True
                self.run_in_progress = False
                self.nav_active = False
                self.run_status = "timeout"
                self.finish_run_and_save()
                self.advance_to_next_goal()

    # ------------------------------------------------------------------
    # CPU LOOP
    # ------------------------------------------------------------------
    def cpu_loop(self, event):
        """Sample CPU and assign to planning or navigation window."""
        cpu_percent = psutil.cpu_percent(interval=None)
        now = rospy.Time.now().to_sec()

        # Planning: goal_sent -> move_start
        if (
            self.run_in_progress
            and (not self.nav_active)
            and (self.t_goal_sent is not None)
            and (self.t_move_start is None)
            and (not self.run_finished)
        ):
            if now >= self.t_goal_sent:
                self.cpu_planning_samples.append(cpu_percent)

        # Navigation: move_start -> goal_reached
        if (
            self.nav_active
            and (self.t_move_start is not None)
            and (not self.run_finished)
        ):
            if now >= self.t_move_start:
                self.cpu_nav_samples.append(cpu_percent)

    # ------------------------------------------------------------------
    # TURN DETECTION
    # ------------------------------------------------------------------
    def update_turn_detection(self, step_dist, dyaw):
        """Count discrete turns based on rotation and small translation."""
        # Need forward motion after a counted turn to rearm
        if (not self.in_turn) and (self.forward_since_turn < self.rearm_forward_dist):
            self.forward_since_turn += step_dist
            return

        # Start new candidate turn
        if (not self.in_turn) and (self.forward_since_turn >= self.rearm_forward_dist):
            if abs(dyaw) > 0.0:
                self.in_turn = True
                self.yaw_accum = abs(dyaw)
                self.turn_forward_dist = step_dist
            return

        # Update current turn
        if self.in_turn:
            self.yaw_accum += abs(dyaw)
            self.turn_forward_dist += step_dist

            # Valid turn
            if (
                self.yaw_accum >= self.turn_yaw_thresh
                and self.turn_forward_dist <= self.turn_dist_thresh
            ):
                self.turn_count += 1
                rospy.loginfo(
                    "Run %d: turn detected, count = %d",
                    self.run_id,
                    self.turn_count,
                )
                self.in_turn = False
                self.forward_since_turn = 0.0
                self.yaw_accum = 0.0
                self.turn_forward_dist = 0.0
                return

            # Too much translation: cancel this candidate
            if self.turn_forward_dist > self.turn_dist_thresh:
                self.in_turn = False
                self.yaw_accum = 0.0
                self.turn_forward_dist = 0.0

    # ------------------------------------------------------------------
    # FINISH RUN AND SAVE
    # ------------------------------------------------------------------
    def finish_run_and_save(self):
        """Compute metrics for one run and write CSV row."""
        goal = self.goals[self.current_goal_index]

        if self.t_goal_sent is None:
            rospy.logwarn("Run %d finished but t_goal_sent is None", self.run_id)
            return

        if self.t_move_start is None:
            # Robot never moved: all time is planning / queue
            self.t_move_start = self.t_goal_sent
            planning_latency = self.t_goal_reached - self.t_goal_sent
            travel_time = 0.0
        else:
            planning_latency = self.t_move_start - self.t_goal_sent
            travel_time = self.t_goal_reached - self.t_move_start

        cpu_plan_peak = (
            max(self.cpu_planning_samples) if self.cpu_planning_samples else 0.0
        )
        cpu_nav_mean = (
            sum(self.cpu_nav_samples) / float(len(self.cpu_nav_samples))
            if self.cpu_nav_samples
            else 0.0
        )

        rospy.loginfo("Results for run %d (%s):", self.run_id, goal["name"])
        rospy.loginfo("  Distance: %.3f m", self.distance_travelled)
        rospy.loginfo("  Travel time: %.3f s", travel_time)
        rospy.loginfo("  Planning latency: %.3f s", planning_latency)
        rospy.loginfo("  Turns: %d", self.turn_count)
        rospy.loginfo("  CPU plan peak: %.1f %%", cpu_plan_peak)
        rospy.loginfo("  CPU nav mean: %.1f %%", cpu_nav_mean)
        rospy.loginfo("  Status: %s", self.run_status)

        self.csv_writer.writerow(
            [
                self.run_id,
                goal["name"],
                "%.4f" % goal["x"],
                "%.4f" % goal["y"],
                "%.4f" % self.distance_travelled,
                "%.4f" % travel_time,
                "%.4f" % planning_latency,
                self.turn_count,
                "%.2f" % cpu_plan_peak,
                "%.2f" % cpu_nav_mean,
                self.run_status,
            ]
        )
        self.csv_file.flush()

    # ------------------------------------------------------------------
    # SHUTDOWN
    # ------------------------------------------------------------------
    def shutdown(self):
        rospy.loginfo("MultiGoalLogger shutting down.")
        try:
            self.csv_file.close()
        except Exception:
            pass


def main():
    rospy.init_node("chapter9_multi_run_logger", anonymous=False)
    node = MultiGoalLogger()
    rospy.on_shutdown(node.shutdown)
    rospy.loginfo("chapter9_multi_run_logger started.")
    rospy.spin()


if __name__ == "__main__":
    main()
