#!/usr/bin/env python3
import rospy
import tf2_ros
from geometry_msgs.msg import TransformStamped

def main():
    rospy.init_node("map_odom_alias_future")

    map_frame = rospy.get_param("~map_frame", "map")
    odom_frame = rospy.get_param("~odom_frame", "odom")
    odom_nav_frame = rospy.get_param("~odom_nav_frame", "odom_nav")

    rate_hz = float(rospy.get_param("~rate", 50.0))
    future_slack = float(rospy.get_param("~future_slack", 0.10))
    tf_timeout = float(rospy.get_param("~tf_timeout", 0.20))

    buf = tf2_ros.Buffer(cache_time=rospy.Duration(30.0))
    lis = tf2_ros.TransformListener(buf)
    br = tf2_ros.TransformBroadcaster()

    rospy.loginfo("Publishing TF %s -> %s by copying %s -> %s with +%.3fs stamp",
                  map_frame, odom_nav_frame, map_frame, odom_frame, future_slack)

    r = rospy.Rate(rate_hz)
    while not rospy.is_shutdown():
        try:
            t = buf.lookup_transform(map_frame, odom_frame, rospy.Time(0), rospy.Duration(tf_timeout))

            out = TransformStamped()
            out.header.frame_id = map_frame
            out.child_frame_id = odom_nav_frame

            out.header.stamp = rospy.Time.now() + rospy.Duration(future_slack)
            out.transform = t.transform

            br.sendTransform(out)

        except Exception as e:
            rospy.logwarn_throttle(2.0, "Waiting TF %s->%s: %s", map_frame, odom_frame, str(e))

        r.sleep()

if __name__ == "__main__":
    main()

