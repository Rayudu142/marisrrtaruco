#!/usr/bin/env python3
import rospy
import tf2_ros
from geometry_msgs.msg import TransformStamped

def main():
    rospy.init_node("map_odom_future_tf")

    parent = rospy.get_param("~parent_frame", "map")
    child  = rospy.get_param("~child_frame",  "odom")

    rate_hz = rospy.get_param("~rate", 50.0)
    future_slack = rospy.get_param("~future_slack", 0.10)  # seconds

    tf_buffer = tf2_ros.Buffer(cache_time=rospy.Duration(30.0))
    tf_listener = tf2_ros.TransformListener(tf_buffer)
    br = tf2_ros.TransformBroadcaster()

    r = rospy.Rate(rate_hz)
    while not rospy.is_shutdown():
        try:
            # Get latest available transform (time=0)
            t = tf_buffer.lookup_transform(parent, child, rospy.Time(0), rospy.Duration(0.2))

            out = TransformStamped()
            out.header.frame_id = parent
            out.child_frame_id = child

            # 
            out.header.stamp = rospy.Time.now() + rospy.Duration(future_slack)

            out.transform.translation = t.transform.translation
            out.transform.rotation = t.transform.rotation

            br.sendTransform(out)

        except Exception:
            # 
            pass

        r.sleep()

if __name__ == "__main__":
    main()

