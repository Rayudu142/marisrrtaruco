#!/usr/bin/env python3
import rospy
import tf2_ros
from geometry_msgs.msg import PoseStamped, TransformStamped
import tf.transformations as tft

def mat_from_trans_quat(t, q):
    m = tft.quaternion_matrix(q)
    m[0, 3] = t[0]
    m[1, 3] = t[1]
    m[2, 3] = t[2]
    return m

def trans_quat_from_mat(m):
    t = (m[0, 3], m[1, 3], m[2, 3])
    q = tft.quaternion_from_matrix(m)
    return t, q

class MapOdomFromSlamOutPose:
    def __init__(self):
        self.map_frame = rospy.get_param("~map_frame", "map")
        self.odom_frame = rospy.get_param("~odom_frame", "odom")
        self.base_frame = rospy.get_param("~base_frame", "base_link")
        self.future_slack = float(rospy.get_param("~future_slack", 0.10))
        self.tf_timeout = float(rospy.get_param("~tf_timeout", 0.30))

        self.tf_buffer = tf2_ros.Buffer(cache_time=rospy.Duration(30.0))
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)
        self.br = tf2_ros.TransformBroadcaster()

        self.sub = rospy.Subscriber("/slam_out_pose", PoseStamped, self.cb, queue_size=10)
        rospy.loginfo("Publishing %s->%s TF from /slam_out_pose and %s->%s TF",
                      self.map_frame, self.odom_frame, self.odom_frame, self.base_frame)

    def cb(self, msg: PoseStamped):
        try:
            tf_ob = self.tf_buffer.lookup_transform(
                self.odom_frame, self.base_frame, rospy.Time(0), rospy.Duration(self.tf_timeout)
            )

            map_T_base = mat_from_trans_quat(
                (msg.pose.position.x, msg.pose.position.y, msg.pose.position.z),
                (msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w)
            )

            odom_T_base = mat_from_trans_quat(
                (tf_ob.transform.translation.x, tf_ob.transform.translation.y, tf_ob.transform.translation.z),
                (tf_ob.transform.rotation.x, tf_ob.transform.rotation.y, tf_ob.transform.rotation.z, tf_ob.transform.rotation.w)
            )

            base_T_odom = tft.inverse_matrix(odom_T_base)
            map_T_odom = map_T_base.dot(base_T_odom)

            t, q = trans_quat_from_mat(map_T_odom)

            out = TransformStamped()
            out.header.frame_id = self.map_frame
            out.child_frame_id = self.odom_frame

            out.header.stamp = rospy.Time.now() + rospy.Duration(self.future_slack)

            out.transform.translation.x = t[0]
            out.transform.translation.y = t[1]
            out.transform.translation.z = t[2]
            out.transform.rotation.x = q[0]
            out.transform.rotation.y = q[1]
            out.transform.rotation.z = q[2]
            out.transform.rotation.w = q[3]

            self.br.sendTransform(out)

        except Exception as e:
            rospy.logwarn_throttle(2.0, "Waiting for TF %s->%s: %s",
                                   self.odom_frame, self.base_frame, str(e))

def main():
    rospy.init_node("map_odom_from_slam_out_pose")
    MapOdomFromSlamOutPose()
    rospy.spin()

if __name__ == "__main__":
    main()

