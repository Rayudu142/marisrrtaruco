#include <rrt_star_planner/rrt_star_planner.h>

#include <pluginlib/class_list_macros.h>
#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/cost_values.h>

#include <algorithm>
#include <cmath>
#include <limits>

namespace rrt_star_planner
{

namespace
{
template <typename T>
bool getParamAny(const std::vector<ros::NodeHandle>& nhs, const std::string& key, T& out)
{
  for (const auto& nh : nhs)
  {
    if (nh.getParam(key, out))
      return true;
  }
  return false;
}
} // namespace

RRTStarPlanner::RRTStarPlanner()
: initialized_(false),
  costmap_ros_(nullptr),
  costmap_(nullptr),
  max_iterations_(1500),
  max_planning_time_(2.0),
  step_size_(0.25),
  goal_bias_(0.15),
  goal_xy_tolerance_(0.35),
  goal_yaw_tolerance_(0.52),
  search_radius_(0.8),
  min_turning_radius_(0.0),
  collision_check_resolution_(0.05),
  minimal_mode_(true),
  reuse_tree_(false),
  reuse_start_tol_(0.25),
  reuse_goal_tol_(0.25),
  allow_unknown_(true),
  lethal_cost_(253),
  rng_(std::random_device{}()),
  uni_(0.0, 1.0),
  has_last_problem_(false)
{
}

RRTStarPlanner::RRTStarPlanner(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
: RRTStarPlanner()
{
  initialize(name, costmap_ros);
}

void RRTStarPlanner::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
{
  if (initialized_)
    return;

  costmap_ros_ = costmap_ros;
  costmap_ = costmap_ros_->getCostmap();

  std::string token = name;
  size_t pos = token.find_last_of('/');
  if (pos != std::string::npos)
    token = token.substr(pos + 1);

  // Robust namespace reading:
  ros::NodeHandle nh_private("~/" + token);
  ros::NodeHandle nh_move_base("/move_base/" + token);
  ros::NodeHandle nh_move_base_node("/move_base/move_base/" + token);

  std::vector<ros::NodeHandle> nhs;
  nhs.push_back(nh_private);
  nhs.push_back(nh_move_base_node);
  nhs.push_back(nh_move_base);

  getParamAny(nhs, "max_iterations", max_iterations_);
  getParamAny(nhs, "max_planning_time", max_planning_time_);
  getParamAny(nhs, "step_size", step_size_);
  getParamAny(nhs, "goal_bias", goal_bias_);
  getParamAny(nhs, "goal_xy_tolerance", goal_xy_tolerance_);
  getParamAny(nhs, "goal_yaw_tolerance", goal_yaw_tolerance_);

  // Accept both keys
  if (!getParamAny(nhs, "rewire_radius", search_radius_))
  {
    getParamAny(nhs, "search_radius", search_radius_);
  }

  getParamAny(nhs, "min_turning_radius", min_turning_radius_);
  getParamAny(nhs, "collision_check_resolution", collision_check_resolution_);
  getParamAny(nhs, "minimal_mode", minimal_mode_);
  getParamAny(nhs, "reuse_tree", reuse_tree_);
  getParamAny(nhs, "reuse_start_tol", reuse_start_tol_);
  getParamAny(nhs, "reuse_goal_tol", reuse_goal_tol_);

  getParamAny(nhs, "allow_unknown", allow_unknown_);
  getParamAny(nhs, "lethal_cost", lethal_cost_);

  plan_pub_ = nh_private.advertise<nav_msgs::Path>("plan", 1, true);

  ROS_INFO("RRTStarPlanner params: allow_unknown=%s lethal_cost=%d rewire_radius(search_radius)=%.2f",
           allow_unknown_ ? "true" : "false",
           lethal_cost_,
           search_radius_);

  ROS_INFO("RRTStarPlanner init. bounds x:[%.2f..%.2f] y:[%.2f..%.2f]",
           costmap_->getOriginX(),
           costmap_->getOriginX() + costmap_->getSizeInMetersX(),
           costmap_->getOriginY(),
           costmap_->getOriginY() + costmap_->getSizeInMetersY());

  initialized_ = true;
}

Node RRTStarPlanner::poseToNode(const geometry_msgs::PoseStamped& pose) const
{
  tf2::Quaternion q;
  tf2::fromMsg(pose.pose.orientation, q);
  double yaw = tf2::getYaw(q);
  return Node(pose.pose.position.x, pose.pose.position.y, yaw);
}

double RRTStarPlanner::distanceXY(const Node& a, const Node& b) const
{
  double dx = a.x - b.x;
  double dy = a.y - b.y;
  return std::sqrt(dx*dx + dy*dy);
}

double RRTStarPlanner::normalizeYaw(double yaw) const
{
  return angles::normalize_angle(yaw);
}

bool RRTStarPlanner::isStateValid(double x, double y) const
{
  unsigned int mx, my;
  if (!costmap_->worldToMap(x, y, mx, my))
    return false;

  unsigned char cost = costmap_->getCost(mx, my);

  if (cost == costmap_2d::NO_INFORMATION)
    return allow_unknown_;

  return static_cast<int>(cost) < lethal_cost_;
}

bool RRTStarPlanner::isMotionValid(const Node& a, const Node& b) const
{
  double dist = distanceXY(a, b);
  int steps = std::max(1, (int)std::ceil(dist / collision_check_resolution_));

  for (int i = 0; i <= steps; ++i)
  {
    double t = (double)i / (double)steps;
    double x = a.x + t * (b.x - a.x);
    double y = a.y + t * (b.y - a.y);
    if (!isStateValid(x, y))
      return false;
  }
  return true;
}

Node RRTStarPlanner::sampleRandomState(const Node& goal)
{
  if (uni_(rng_) < goal_bias_)
    return goal;

  double minx = costmap_->getOriginX();
  double miny = costmap_->getOriginY();
  double maxx = minx + costmap_->getSizeInMetersX();
  double maxy = miny + costmap_->getSizeInMetersY();

  double rx = minx + uni_(rng_) * (maxx - minx);
  double ry = miny + uni_(rng_) * (maxy - miny);
  double ryaw = -M_PI + uni_(rng_) * (2.0 * M_PI);

  return Node(rx, ry, ryaw);
}

int RRTStarPlanner::nearestNode(const Node& q) const
{
  if (tree_.empty())
    return -1;

  int best = 0;
  double best_d = std::numeric_limits<double>::infinity();

  for (int i = 0; i < (int)tree_.size(); ++i)
  {
    double d = distanceXY(tree_[i], q);
    if (d < best_d)
    {
      best_d = d;
      best = i;
    }
  }
  return best;
}

std::vector<int> RRTStarPlanner::nearNodes(const Node& q) const
{
  std::vector<int> idxs;
  double r = search_radius_;
  double r2 = r * r;

  for (int i = 0; i < (int)tree_.size(); ++i)
  {
    double dx = tree_[i].x - q.x;
    double dy = tree_[i].y - q.y;
    double d2 = dx*dx + dy*dy;
    if (d2 <= r2)
      idxs.push_back(i);
  }
  return idxs;
}

int RRTStarPlanner::extendTree(int near_idx, const Node& q_rand)
{
  const Node& q_near = tree_[near_idx];

  double dx = q_rand.x - q_near.x;
  double dy = q_rand.y - q_near.y;
  double dist = std::sqrt(dx*dx + dy*dy);

  Node q_new = q_rand;
  if (dist > step_size_ && dist > 1e-9)
  {
    double scale = step_size_ / dist;
    q_new.x = q_near.x + dx * scale;
    q_new.y = q_near.y + dy * scale;
  }

  q_new.yaw = std::atan2(q_new.y - q_near.y, q_new.x - q_near.x);
  q_new.yaw = normalizeYaw(q_new.yaw);

  if (!isMotionValid(q_near, q_new))
    return -1;

  tree_.push_back(q_new);
  return (int)tree_.size() - 1;
}

void RRTStarPlanner::rewire(int /*new_idx*/)
{
  // 
}

bool RRTStarPlanner::goalReached(const Node& q, const Node& goal) const
{
  double d = distanceXY(q, goal);
  if (d > goal_xy_tolerance_)
    return false;

  double dyaw = angles::shortest_angular_distance(q.yaw, goal.yaw);
  return std::fabs(dyaw) <= goal_yaw_tolerance_;
}

void RRTStarPlanner::extractPath(const Node& goal, std::vector<geometry_msgs::PoseStamped>& plan) const
{
  int best_idx = -1;
  double best = std::numeric_limits<double>::infinity();

  for (size_t i = 0; i < tree_.size(); ++i)
  {
    if (goalReached(tree_[i], goal))
    {
      double d = distanceXY(tree_[i], goal);
      if (d < best)
      {
        best = d;
        best_idx = (int)i;
      }
    }
  }

  if (best_idx < 0)
    return;

  plan.clear();
  plan.reserve((size_t)best_idx + 2);

  // Critical fix
  const ros::Time stamp = ros::Time(0);
  const std::string frame = costmap_ros_->getGlobalFrameID();

  for (int i = 0; i <= best_idx; ++i)
  {
    const Node& n = tree_[(size_t)i];

    geometry_msgs::PoseStamped p;
    p.header.frame_id = frame;
    p.header.stamp = stamp;
    p.pose.position.x = n.x;
    p.pose.position.y = n.y;
    p.pose.position.z = 0.0;

    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, n.yaw);
    p.pose.orientation = tf2::toMsg(q);

    plan.push_back(p);
  }

  geometry_msgs::PoseStamped g;
  g.header.frame_id = frame;
  g.header.stamp = stamp;
  g.pose.position.x = goal.x;
  g.pose.position.y = goal.y;
  g.pose.position.z = 0.0;

  tf2::Quaternion qg;
  qg.setRPY(0.0, 0.0, goal.yaw);
  g.pose.orientation = tf2::toMsg(qg);

  plan.push_back(g);
}

bool RRTStarPlanner::makePlan(const geometry_msgs::PoseStamped& start,
                              const geometry_msgs::PoseStamped& goal,
                              std::vector<geometry_msgs::PoseStamped>& plan)
{
  plan.clear();

  if (!initialized_)
  {
    ROS_ERROR("RRTStarPlanner not initialized");
    return false;
  }

  Node q_start = poseToNode(start);
  Node q_goal  = poseToNode(goal);

  if (!isStateValid(q_start.x, q_start.y))
  {
    ROS_WARN("RRT*: start is not valid on costmap. allow_unknown=%s lethal_cost=%d",
             allow_unknown_ ? "true" : "false", lethal_cost_);
    ROS_INFO("RRT* plan: found=false, size=0");
    return false;
  }
  if (!isStateValid(q_goal.x, q_goal.y))
  {
    ROS_WARN("RRT*: goal is not valid on costmap. allow_unknown=%s lethal_cost=%d",
             allow_unknown_ ? "true" : "false", lethal_cost_);
    ROS_INFO("RRT* plan: found=false, size=0");
    return false;
  }

  bool can_reuse = reuse_tree_ && has_last_problem_ &&
                   (distanceXY(q_start, last_start_) <= reuse_start_tol_) &&
                   (distanceXY(q_goal,  last_goal_)  <= reuse_goal_tol_);

  if (!can_reuse)
  {
    tree_.clear();
    tree_.reserve((size_t)max_iterations_ + 1);
    tree_.push_back(q_start);
  }
  else
  {
    ROS_INFO("RRT* reusing previous tree (soft reuse).");
  }

  has_last_problem_ = true;
  last_start_ = q_start;
  last_goal_  = q_goal;

  ros::Time t0 = ros::Time::now();
  bool found = false;

  for (int i = 0; i < max_iterations_; ++i)
  {
    if ((ros::Time::now() - t0).toSec() > max_planning_time_)
      break;

    Node q_rand = sampleRandomState(q_goal);
    int q_near_idx = nearestNode(q_rand);
    if (q_near_idx < 0)
      continue;

    int q_new_idx = extendTree(q_near_idx, q_rand);
    if (q_new_idx < 0)
      continue;

    if (!minimal_mode_)
      rewire(q_new_idx);

    if (goalReached(tree_[(size_t)q_new_idx], q_goal))
    {
      found = true;
      break;
    }
  }

  if (!found)
  {
    ROS_INFO("RRT* plan: found=false, size=0");
    return false;
  }

  extractPath(q_goal, plan);

  nav_msgs::Path path;
  path.header.frame_id = costmap_ros_->getGlobalFrameID();
  path.header.stamp = ros::Time(0);  // same TF-safe stamping
  path.poses = plan;
  plan_pub_.publish(path);

  ROS_INFO("RRT* plan: found=%s, size=%zu", (found ? "true" : "false"), plan.size());
  return !plan.empty();
}

} // namespace rrt_star_planner

PLUGINLIB_EXPORT_CLASS(rrt_star_planner::RRTStarPlanner, nav_core::BaseGlobalPlanner)

